import React, { Component    } from 'react';
import Link from 'next/link';
import Image from 'next/image';
const Footer = () => {
    return (
        <footer>
 <footer>

    </footer>
</footer>
    )
}
export default Footer;




